import tkinter as tk
from tkinter import Frame, font
from tkinter import ttk
from tkinter.constants import N
from tkinter.font import Font 
import parameters as params 
import connection as connect

def choose():
    window = tk.Tk()
    window.geometry("200x100")
    window.configure(bg="black")
    window.title("Choose")

    frame_entry = tk.Frame(master=window, bg ="black")
    parameters_btn = tk.Button(master=frame_entry, text="Parameters", bg="black", fg="red", font=("rationale",12), command = lambda:params.handle_values())
    connections_btn= tk.Button(master=frame_entry, text="Connections", bg="black", fg="red", font=("rationale",12), command = lambda:connect.handle_connections()) 

    frame_entry.grid(row=0, column=0, padx=10)
    parameters_btn.grid(row=0, column=0, padx=10)
    connections_btn.grid(row=1, column=0, padx=10)
    window.mainloop()

 




