import serial
import struct


def getParams(select, rate_adapt, values): 

    if values[7]=="V-Low":
        values[7]=1
    elif values[7]=="Low":
        values[7]=2
    elif values[7]=="Med-Low":
        values[7]=3
    elif values[7]=="Med":
        values[7]=4
    elif values[7]=="Med-High":
        values[7]=5
    elif values[7]=="High":
        values[7]=6
    else:
        values[7]=7


    finalParam = [22, int(select), int(values[0]), 0, int(values[1]), 0, int(values[2]), int(values[3]), int(values[4]), 0, int(values[5]), int(values[6]), int(values[7]), int(values[8]), int(rate_adapt), int(values[9]), int(values[10]), int(values[11])]
    conversion = "<BBBBBBBBBBBBBBBBBB"
    sendParams(finalParam, conversion)

def sendParams(finalParam, conversion):

    packet=[]
    ser = serial.Serial()

    #Change to your COM Port for the pacemaker
    ser.port = 'COM3' 
    ser.buadrate=9600
    ser.open()

    packet = []

    assert(len(conversion[1:]) == len(finalParam)), "conversion doesnt match value"
    endian = conversion[0]
    conversion = conversion[1:]


    for i in range(0, len(finalParam)):
        data = struct.pack(endian+conversion[i],finalParam[i])
        packet.append(data)
    for pack in packet:
        ser.write(pack)
        print(pack)
    ser.close()
    
