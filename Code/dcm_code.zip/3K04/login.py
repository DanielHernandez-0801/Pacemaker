import tkinter as tk
from tkinter import Frame, font
from tkinter import ttk
from tkinter.constants import N
from tkinter.font import Font 
import choose as code

def handle_welcome_login(): 
    #creating the LOGIN window 
    window = tk.Tk() 
    window.geometry("400x150")
    window.configure(bg="black")
    window.title("LOGIN")

    #creating the frame 
    frame_entry = tk.Frame(master=window, bg= "black")

    #adding widgets 
    username = tk.Label(master=frame_entry, text="Username:", fg = "red", bg= "black", 
        font=("Rationale", 12, "bold"))
    input_username = tk.Entry(master=frame_entry, fg = "black", width = 20, font=("Rationale", 12, "bold"))
    password = tk.Label(master=frame_entry, text="Password:", fg = "red", bg= "black", 
        font=("Rationale", 12, "bold"))
    input_password = tk.Entry(master=frame_entry, fg = "black", width = 20, font=("Rationale", 12, "bold"))
    login = tk.Button(master = frame_entry, text ="Login", bg = "black", fg = "red", 
        font=("Rationale", 11),
        command= lambda: handle_login(input_username, input_password))
    register = tk.Button(master = frame_entry, text ="Register", bg = "black", fg = "red", 
        font=("Rationale", 11),
        command=lambda: handle_register(input_username, input_password))
    
    #organizing widgets 
    frame_entry.grid(row=0, column =0, padx =10)
    username.grid(row=0, column =0, sticky ="w")
    input_username.grid(row=0, column = 1, sticky ="e")
    password.grid(row=1, column =0, sticky ="w")
    input_password.grid(row=1, column = 1, sticky ="e")
    login.grid(row=2, column =0, padx = 5)
    register.grid(row=2, column =1, padx = 5)

    window.mainloop()

def handle_login(username, password): 
    user = username.get()
    passw = password.get()
    users = []
    passwords = []
    usersinfo = open("database.txt", "r")
    for i in usersinfo:
        a,b = i.split(", ")
        b = b.strip()
        users.append(a)
        passwords.append(b) 
    data = dict(zip(users,passwords))
    try:
        if data[user]:
            try:
                if passw == data[user]:
                    code.choose()
                else:
                    print("Unsuccessful")
            except:
                print("Unsuccessful")
        else:
            print("Not registered")
    except:
        print("Unsuccssful")
    usersinfo.close()

def handle_register(username, password):
    data = {}
    users = []
    passwords = []
    file = open("database.txt", "r")
    linecounter = 0
    for line in file:
        if line != "\n":
            linecounter+=1
    file.close()
    while(linecounter < 10):
        user = username.get()
        passw = password.get()
        usersinfo = open("database.txt", "r")
        for i in usersinfo:
            a,b = i.split(", ")
            b = b.strip()
            users.append(a)
            passwords.append(b) 
        data = dict(zip(users,passwords))
        if len(passw)<=5:
            print("Password has to be longer than 5 characters, try again.")
            break
        elif len(user)<=5:
            print("Username has to be longer than 5 characters, try again.")
            break
        elif user in users:
            print("Error, user exists")
            break
        else:
            usersinfo = open("database.txt", "a")
            usersinfo.write(user+", "+passw+"\n")
            usersinfo.close()
            print("User Added, Please Login.")
            break
    if (linecounter == 10):
        print("Max users reached")

