import tkinter as tk
from tkinter import Frame, font
from tkinter import ttk
from tkinter.constants import N, RIGHT, Y
from tkinter.font import Font
from typing import Text 
import serial_test as serCom


def handle_values(): 
    window = tk.Tk()
    window.geometry("500x700")
    window.configure(bg="black")
    window.title("VALUES")

    tabControl = ttk.Notebook(window)
    tabControl.pack(pady=1)


    tab1 = Frame(tabControl, bg="black")
    tab2 = Frame(tabControl, bg="black") 
    tab3 = Frame(tabControl, bg="black")
    tab4 = Frame(tabControl, bg="black")
    tab5 = Frame(tabControl, bg="black")
    tab6 = Frame(tabControl, bg="black")
    tab7 = Frame(tabControl, bg="black")
    tab8 = Frame(tabControl, bg="black")
    tab9 = Frame(tabControl, bg="black")
    tab10 = Frame(tabControl, bg="black")

    tab1.pack(fill="both", expand=1)
    tab2.pack(fill="both", expand=1)
    tab3.pack(fill="both", expand=1)
    tab4.pack(fill="both", expand=1)
    tab5.pack(fill="both", expand=1)
    tab6.pack(fill="both", expand=1)
    tab7.pack(fill="both", expand=1)
    tab8.pack(fill="both", expand=1)
    tab9.pack(fill="both", expand=1)
    tab10.pack(fill="both", expand=1)

    tabControl.add(tab1, text = "AOO")
    tabControl.add(tab2, text = "VOO")
    tabControl.add(tab3, text = "AAI")
    tabControl.add(tab4, text = "VVI")
    tabControl.add(tab5, text = "DOO")
    tabControl.add(tab6, text = "AOOR")
    tabControl.add(tab7, text = "VOOR")
    tabControl.add(tab8, text = "AAIR")
    tabControl.add(tab9, text = "VVIR")
    tabControl.add(tab10, text = "DOOR")


    tab1Values = []
    tab2Values = []
    tab3Values = []
    tab4Values = []
    tab5Values = []
    tab6Values = []
    tab7Values = []
    tab8Values = []
    tab9Values = []
    tab10Values = []

    tab1Names = []
    tab2Names = []
    tab3Names = []
    tab4Names = []
    tab5Names = []
    tab6Names = []
    tab7Names = []
    tab8Names = []
    tab9Names = []
    tab10Names = []

    #parameters 
    #TAB 1
    tk.Label(tab1, text ="Lower Rate Limit", fg = "red", bg= "black").grid(column = 0, row = 0, padx = 10, pady = 10)
    tk.Label(tab1, text ="Upper Rate Limit", fg = "red", bg= "black").grid(column = 0, row = 1, padx = 10, pady = 10)
    tk.Label(tab1, text ="Atrial Amplitude", fg = "red", bg= "black").grid(column = 0, row = 2, padx = 10, pady = 10)
    tk.Label(tab1, text ="Atrial Pulse Width", fg = "red", bg= "black").grid(column = 0, row = 3, padx = 10, pady = 10)

    LRL1 = tk.Spinbox(tab1, from_=30, to=175, increment = 1, wrap=True)
    LRL1.grid(column = 1, row = 0, padx = 10, pady = 10)
    input_Upper1 = tk.Spinbox(tab1, from_=50, to=175, increment = 5, wrap=True)
    input_Upper1.grid(column = 1, row = 1, padx = 10, pady = 10)
    Amplitude1 = tk.Spinbox(tab1, from_=0, to=5000, increment = 100, wrap=True)
    Amplitude1.grid(column = 1, row = 2, padx = 10, pady = 10)
    APW1 = tk.Spinbox(tab1, from_=1, to=30, increment = 1, wrap=True)
    APW1.grid(column = 1, row = 3, padx = 10, pady = 10)

    tab1Values.append(int(LRL1.get())) #LRL
    tab1Values.append(0) #Refeac Period
    tab1Values.append(0) #AV Delay
    tab1Values.append(int(APW1.get())) #APW
    tab1Values.append(0) #VPW
    tab1Values.append(int(Amplitude1.get())) #amplitude
    tab1Values.append(0) #Sensing Threshold
    tab1Values.append(0) #Activity Treshold
    tab1Values.append(0) #RF
    tab1Values.append(0) #MSR
    tab1Values.append(0) #Recover time
    tab1Values.append(0) #Reaction time
    tab1Values.append(int(input_Upper1.get()))


    tab1Names.append("LRL1")
    tab1Names.append("input_Upper1")
    tab1Names.append("Amplitude1")
    tab1Names.append("APW1")

    label1 = tk.Label(tab1,text="")
    label1.grid(column = 3, row = 0, padx = 10, pady = 10)
    
    label2 = tk.Label(tab1,text="")
    label2.grid(column = 3, row = 1, padx = 10, pady = 10)

    label3 = tk.Label(tab1,text="")
    label3.grid(column = 3, row = 2, padx = 10, pady = 10)

    label4 = tk.Label(tab1,text="")
    label4.grid(column = 3, row = 3, padx = 10, pady = 10)

    def grab1():
        label1.config(text=LRL1.get())
        label2.config(text=input_Upper1.get())
        label3.config(text=Amplitude1.get())
        label4.config(text=APW1.get())
    submit1 = tk.Button(tab1, text ="Submit", bg = "black", fg = "red", font=("Rationale", 11), command = lambda:[handle_submit_AOO(tab1Values, tab1Names, 13), grab1()])
    submit1.grid(column = 1, row = 4, padx = 10, pady = 10)

    #TAB 2
    tk.Label(tab2, text ="Lower Rate Limit", fg = "red", bg= "black").grid(column = 0, row = 0, padx = 10, pady = 10)
    tk.Label(tab2, text ="Upper Rate Limit", fg = "red", bg= "black").grid(column = 0, row = 1, padx = 10, pady = 10)
    tk.Label(tab2, text ="Ventricular Amplitude", fg = "red", bg= "black").grid(column = 0, row = 2, padx = 10, pady = 10)
    tk.Label(tab2, text ="Ventricular Pulse Width", fg = "red", bg= "black").grid(column = 0, row = 3, padx = 10, pady = 10)
    LRL2 = tk.Spinbox(tab2, from_=30, to=175, increment = 1, wrap=True)
    LRL2.grid(column = 1, row = 0, padx = 10, pady = 10)
    input_Upper2 = tk.Spinbox(tab2, from_=50, to=175, increment = 5, wrap=True)
    input_Upper2.grid(column = 1, row = 1, padx = 10, pady = 10)
    Amplitude2 = tk.Spinbox(tab2, from_= 0, to=5000, increment = 100, wrap=True)
    Amplitude2.grid(column = 1, row = 2, padx = 10, pady = 10)
    VPW2 = tk.Spinbox(tab2, from_=1, to=30, increment = 1, wrap=True)
    VPW2.grid(column = 1, row = 3, padx = 10, pady = 10)

    tab2Values.append(int(LRL2.get())) #LRL
    tab2Values.append(0) #Refeac Period
    tab2Values.append(0) #AV Delay
    tab2Values.append(0) #APW
    tab2Values.append(int(VPW2.get())) #VPW
    tab2Values.append(int(Amplitude2.get())) #amplitude
    tab2Values.append(0) #Sensing Threshold
    tab2Values.append(0) #Activity Treshold
    tab2Values.append(0) #RF
    tab2Values.append(0) #MSR
    tab2Values.append(0) #Recover time
    tab2Values.append(0) #Reaction time
    tab2Values.append(int(input_Upper2.get()))


    tab2Names.append("LRL2")
    tab2Names.append("input_Upper2")
    tab2Names.append("Amplitude2")
    tab2Names.append("VPW2")

    
    label5 = tk.Label(tab2,text="")
    label5.grid(column = 3, row = 0, padx = 10, pady = 10)
    
    label6 = tk.Label(tab2,text="")
    label6.grid(column = 3, row = 1, padx = 10, pady = 10)

    label7 = tk.Label(tab2,text="")
    label7.grid(column = 3, row = 2, padx = 10, pady = 10)

    label8 = tk.Label(tab2,text="")
    label8.grid(column = 3, row = 3, padx = 10, pady = 10)
    
    def grab2():
        label5.config(text=LRL2.get())
        label6.config(text=input_Upper2.get())
        label7.config(text=Amplitude2.get())
        label8.config(text=VPW2.get())

    submit2 = tk.Button(tab2, text ="Submit", bg = "black", fg = "red", font=("Rationale", 11), command = lambda:[handle_submit_VOO(tab2Values, tab2Names, 13), grab2()])
    submit2.grid(column = 1, row = 4, padx = 10, pady = 10)

    #TAB 3
    tk.Label(tab3, text ="Lower Rate Limit", fg = "red", bg= "black").grid(column = 0, row = 0, padx = 10, pady = 10)
    tk.Label(tab3, text ="Upper Rate Limit", fg = "red", bg= "black").grid(column = 0, row = 1, padx = 10, pady = 10)
    tk.Label(tab3, text ="Atrial Amplitude", fg = "red", bg= "black").grid(column = 0, row = 2, padx = 10, pady = 10)
    tk.Label(tab3, text ="Atrial Pulse Width", fg = "red", bg= "black").grid(column = 0, row = 3, padx = 10, pady = 10)
    tk.Label(tab3, text ="Atrial Sensitivity", fg = "red", bg= "black").grid(column = 0, row = 4, padx = 10, pady = 10)
    tk.Label(tab3, text ="ARP", fg = "red", bg= "black").grid(column = 0, row = 5, padx = 10, pady = 10)
    tk.Label(tab3, text ="PVARP", fg = "red", bg= "black").grid(column = 0, row = 6, padx = 10, pady = 10)
    tk.Label(tab3, text ="Hysteresis", fg = "red", bg= "black").grid(column = 0, row = 7, padx = 10, pady = 10)
    tk.Label(tab3, text ="Rate Smoothing", fg = "red", bg= "black").grid(column = 0, row = 8, padx = 10, pady = 10)
    LRL3 = tk.Spinbox(tab3, from_=30, to=175, increment = 1, wrap=True)
    LRL3.grid(column = 1, row = 0, padx = 10, pady = 10)
    input_Upper3 = tk.Spinbox(tab3, from_=50, to=175, increment = 5, wrap=True)
    input_Upper3.grid(column = 1, row = 1, padx = 10, pady = 10)
    Amplitude3 = tk.Spinbox(tab3, from_= 0, to=5000, increment = 100, wrap=True)
    Amplitude3.grid(column = 1, row = 2, padx = 10, pady = 10)
    APW3 = tk.Spinbox(tab3, from_=1, to=30, increment = 1, wrap=True)
    APW3.grid(column = 1, row = 3, padx = 10, pady = 10)
    Sensing_Threshold3 = tk.Spinbox(tab3, from_=0, to=5000, increment = 100, wrap=True)
    Sensing_Threshold3.grid(column = 1, row = 4, padx = 10, pady = 10)
    Refrac_Period3 = tk.Spinbox(tab3, from_=150, to=500, increment = 10, wrap=True)
    Refrac_Period3.grid(column = 1, row = 5, padx = 10, pady = 10)
    input_Pvarp3 = tk.Spinbox(tab3, from_=150, to=500, increment = 10, wrap=True)
    input_Pvarp3.grid(column = 1, row = 6, padx = 10, pady = 10)
    input_Hyster3 = tk.Spinbox(tab3, from_=30, to=175, increment = 1, wrap=True)
    input_Hyster3.grid(column = 1, row = 7, padx = 10, pady = 10)
    input_Smoot3 = tk.Spinbox(tab3, from_=0, to=21, increment = 3, wrap=True)
    input_Smoot3.grid(column = 1, row = 8, padx = 10, pady = 10)
    

    tab3Values.append(int(LRL3.get())) #LRL
    tab3Values.append(int(Refrac_Period3.get())) #Refeac Period
    tab3Values.append(0) #AV Delay
    tab3Values.append(int(APW3.get())) #APW
    tab3Values.append(0) #VPW
    tab3Values.append(int(Amplitude3.get())) #amplitude
    tab3Values.append(int(Sensing_Threshold3.get())) #Sensing Threshold
    tab3Values.append(0) #Activity Treshold
    tab3Values.append(0) #RF
    tab3Values.append(0) #MSR
    tab3Values.append(0) #Recover time
    tab3Values.append(0) #Reaction time
    tab3Values.append(int(input_Upper3.get()))
    tab3Values.append(int(input_Pvarp3.get()))
    tab3Values.append(int(input_Hyster3.get()))
    tab3Values.append(int(input_Smoot3.get()))

    tab3Names.append("LRL3")
    tab3Names.append("input_Upper3")
    tab3Names.append("Amplitude3")
    tab3Names.append("APW3")
    tab3Names.append("Sensing_Threshold3")
    tab3Names.append("Refrac_Period3")
    tab3Names.append("input_Pvarp3")
    tab3Names.append("input_Hyster3")
    tab3Names.append("input_Smoot3")

    label9 = tk.Label(tab3,text="")
    label9.grid(column = 3, row = 0, padx = 10, pady = 10)

    label10 = tk.Label(tab3,text="")
    label10.grid(column = 3, row = 1, padx = 10, pady = 10)

    label11 = tk.Label(tab3,text="")
    label11.grid(column = 3, row = 2, padx = 10, pady = 10)

    label12 = tk.Label(tab3,text="")
    label12.grid(column = 3, row = 3, padx = 10, pady = 10)

    label13 = tk.Label(tab3,text="")
    label13.grid(column = 3, row = 4, padx = 10, pady = 10)

    label14 = tk.Label(tab3,text="")
    label14.grid(column = 3, row = 5, padx = 10, pady = 10)

    label15 = tk.Label(tab3,text="")
    label15.grid(column = 3, row = 6, padx = 10, pady = 10)

    label16 = tk.Label(tab3,text="")
    label16.grid(column = 3, row = 7, padx = 10, pady = 10)

    label17 = tk.Label(tab3,text="")
    label17.grid(column = 3, row = 8, padx = 10, pady = 10)

    def grab3():
        label9.config(text=LRL3.get())
        label10.config(text=input_Upper3.get())
        label11.config(text=Amplitude3.get())
        label12.config(text=APW3.get())
        label13.config(text=Sensing_Threshold3.get())
        label14.config(text=Refrac_Period3.get())
        label15.config(text=input_Pvarp3.get())
        label16.config(text=input_Hyster3.get())
        label17.config(text=input_Smoot3.get())

    submit3 = tk.Button(tab3, text ="Submit", bg = "black", fg = "red", font=("Rationale", 11), command = lambda:[handle_submit_AAI(tab3Values, tab3Names, 9), grab3()])
    submit3.grid(column = 1, row = 9, padx = 10, pady = 10)

    #TAB 4
    tk.Label(tab4, text ="Lower Rate Limit", fg = "red", bg= "black").grid(column = 0, row = 0, padx = 10, pady = 10)
    tk.Label(tab4, text ="Upper Rate Limit", fg = "red", bg= "black").grid(column = 0, row = 1, padx = 10, pady = 10)
    tk.Label(tab4, text ="Ventricular Amplitude", fg = "red", bg= "black").grid(column = 0, row = 2, padx = 10, pady = 10)
    tk.Label(tab4, text ="Ventricular Pulse Width", fg = "red", bg= "black").grid(column = 0, row = 3, padx = 10, pady = 10)
    tk.Label(tab4, text ="Ventricular Sensitivity", fg = "red", bg= "black").grid(column = 0, row = 4, padx = 10, pady = 10)
    tk.Label(tab4, text ="VRP", fg = "red", bg= "black").grid(column = 0, row = 5, padx = 10, pady = 10)
    tk.Label(tab4, text ="Hysteresis", fg = "red", bg= "black").grid(column = 0, row = 6, padx = 10, pady = 10)
    tk.Label(tab4, text ="Rate Smoothing", fg = "red", bg= "black").grid(column = 0, row = 7, padx = 10, pady = 10)
    LRL4 = tk.Spinbox(tab4, from_=30, to=175, increment = 1, wrap=True)
    LRL4.grid(column = 1, row = 0, padx = 10, pady = 10)
    input_Upper4 = tk.Spinbox(tab4, from_=50, to=175, increment = 5, wrap=True)
    input_Upper4.grid(column = 1, row = 1, padx = 10, pady = 10)
    Amplitude4 = tk.Spinbox(tab4, from_= 0, to=5000, increment = 100, wrap=True)
    Amplitude4.grid(column = 1, row = 2, padx = 10, pady = 10)
    VPW4 = tk.Spinbox(tab4, from_=1, to=30, increment = 1, wrap=True)
    VPW4.grid(column = 1, row = 3, padx = 10, pady = 10)
    Sensing_Threshold4 = tk.Spinbox(tab4, from_=0, to=5000, increment = 100, wrap=True)
    Sensing_Threshold4.grid(column = 1, row = 4, padx = 10, pady = 10)
    Refrac_Period4 = tk.Spinbox(tab4, from_=150, to=500, increment = 10, wrap=True)
    Refrac_Period4.grid(column = 1, row = 5, padx = 10, pady = 10)
    input_Hyster4 = tk.Spinbox(tab4, from_=30, to=175, increment = 1, wrap=True)
    input_Hyster4.grid(column = 1, row = 6, padx = 10, pady = 10)
    input_Smoot4 = tk.Spinbox(tab4, from_=0, to=21, increment = 3, wrap=True)
    input_Smoot4.grid(column = 1, row = 7, padx = 10, pady = 10)

    tab4Values.append(int(LRL4.get())) #LRL
    tab4Values.append(int(Refrac_Period4.get())) #Refeac Period
    tab4Values.append(0) #AV Delay
    tab4Values.append(0) #APW
    tab4Values.append(int(VPW4.get())) #VPW
    tab4Values.append(int(Amplitude4.get())) #amplitude
    tab4Values.append(int(Sensing_Threshold4.get())) #Sensing Threshold
    tab4Values.append(0) #Activity Treshold
    tab4Values.append(0) #RF
    tab4Values.append(0) #MSR
    tab4Values.append(0) #Recover time
    tab4Values.append(0) #Reaction time
    tab4Values.append(int(input_Upper4.get()))
    tab4Values.append(int(input_Hyster4.get()))
    tab4Values.append(int(input_Smoot4.get()))

    tab4Names.append("LRL4")
    tab4Names.append("input_Upper4")
    tab4Names.append("Amplitude4")
    tab4Names.append("VPW")
    tab4Names.append("Sensing_Threshold4")
    tab4Names.append("Refrac_Period4")
    tab4Names.append("input_Hyster4")
    tab4Names.append("input_Smoot4")


    label18 = tk.Label(tab4,text="")
    label18.grid(column = 3, row = 0, padx = 10, pady = 10)

    label19 = tk.Label(tab4,text="")
    label19.grid(column = 3, row = 1, padx = 10, pady = 10)

    label20 = tk.Label(tab4,text="")
    label20.grid(column = 3, row = 2, padx = 10, pady = 10)

    label21 = tk.Label(tab4,text="")
    label21.grid(column = 3, row = 3, padx = 10, pady = 10)

    label22 = tk.Label(tab4,text="")
    label22.grid(column = 3, row = 4, padx = 10, pady = 10)

    label23 = tk.Label(tab4,text="")
    label23.grid(column = 3, row = 5, padx = 10, pady = 10)

    label24 = tk.Label(tab4,text="")
    label24.grid(column = 3, row = 6, padx = 10, pady = 10)

    label25 = tk.Label(tab4,text="")
    label25.grid(column = 3, row = 7, padx = 10, pady = 10)

    def grab4():
        label18.config(text=LRL4.get())
        label19.config(text=input_Upper4.get())
        label20.config(text=Amplitude4.get())
        label21.config(text=VPW4.get())
        label22.config(text=Sensing_Threshold4.get())
        label23.config(text=Refrac_Period4.get())
        label24.config(text=input_Hyster4.get())
        label25.config(text=input_Smoot4.get())

    submit4 = tk.Button(tab4, text ="Submit", bg = "black", fg = "red", font=("Rationale", 11), command = lambda:[handle_submit_VVI(tab4Values, tab4Names, 8), grab4()])
    submit4.grid(column = 1, row = 10, padx = 10, pady = 10)

    #TAB 5
    tk.Label(tab5, text ="Lower Rate Limit", fg = "red", bg= "black").grid(column = 0, row = 0, padx = 10, pady = 10)
    tk.Label(tab5, text ="Upper Rate Limit", fg = "red", bg= "black").grid(column = 0, row = 1, padx = 10, pady = 10)
    tk.Label(tab5, text ="Atrial Amplitude", fg = "red", bg= "black").grid(column = 0, row = 2, padx = 10, pady = 10)
    tk.Label(tab5, text ="Atrial Pulse Width", fg = "red", bg= "black").grid(column = 0, row = 3, padx = 10, pady = 10)
    tk.Label(tab5, text ="Ventricular Amplitude", fg = "red", bg= "black").grid(column = 0, row = 4, padx = 10, pady = 10)
    tk.Label(tab5, text ="Ventricular Pulse Width", fg = "red", bg= "black").grid(column = 0, row = 5, padx = 10, pady = 10)
    tk.Label(tab5, text ="Fixed AV Delay", fg = "red", bg= "black").grid(column = 0, row = 6, padx = 10, pady = 10)
    var = tk.StringVar()
    LRL5 = tk.Spinbox(tab5, from_=30, to=175, increment = 1, wrap=True)
    LRL5.grid(column = 1, row = 0, padx = 10, pady = 10)
    input_Upper5 = tk.Spinbox(tab5, from_=50, to=175, increment = 5, wrap=True)
    input_Upper5.grid(column = 1, row = 1, padx = 10, pady = 10)
    Amplitude5 = tk.Spinbox(tab5, from_= 0, to=5000, increment = 100, wrap=True)
    Amplitude5.grid(column = 1, row = 2, padx = 10, pady = 10)
    APW5 = tk.Spinbox(tab5, from_=1, to=30, increment = 1, wrap=True)
    APW5.grid(column = 1, row = 3, padx = 10, pady = 10)
    input_VAmp5 = tk.Spinbox(tab5, from_=0, to=5, increment = 0.1, wrap=True)
    input_VAmp5.grid(column = 1, row = 4, padx = 10, pady = 10)
    VPW5 = tk.Spinbox(tab5, from_=1, to=30, increment = 1, wrap=True)
    VPW5.grid(column = 1, row = 5, padx = 10, pady = 10)
    AV_Delay5 = tk.Spinbox(tab5, from_=70, to=300, increment = 10, wrap=True)
    AV_Delay5.grid(column = 1, row = 6, padx = 10, pady = 10)

    tab5Values.append(int(LRL5.get())) #LRL
    tab5Values.append(0) #Refeac Period
    tab5Values.append(int(AV_Delay5.get())) #AV Delay
    tab5Values.append(int(APW5.get())) #APW
    tab5Values.append(int(VPW5.get())) #VPW
    tab5Values.append(int(Amplitude5.get())) #amplitude
    tab5Values.append(0) #Sensing Threshold
    tab5Values.append(0) #Activity Treshold
    tab5Values.append(0) #RF
    tab5Values.append(0) #MSR
    tab5Values.append(0) #Recover time
    tab5Values.append(0) #Reaction time
    tab5Values.append(int(input_Upper5.get()))

    tab5Names.append("LRL5")
    tab5Names.append("input_Upper5")
    tab5Names.append("Amplitude5")
    tab5Names.append("APW5")
    tab5Names.append("input_VAmp5")
    tab5Names.append("VPW")
    tab5Names.append("AV_Delay5")


    label26 = tk.Label(tab5,text="")
    label26.grid(column = 3, row = 0, padx = 10, pady = 10)

    label27 = tk.Label(tab5,text="")
    label27.grid(column = 3, row = 1, padx = 10, pady = 10)

    label28 = tk.Label(tab5,text="")
    label28.grid(column = 3, row = 2, padx = 10, pady = 10)

    label29 = tk.Label(tab5,text="")
    label29.grid(column = 3, row = 3, padx = 10, pady = 10)

    label30 = tk.Label(tab5,text="")
    label30.grid(column = 3, row = 4, padx = 10, pady = 10)

    label31 = tk.Label(tab5,text="")
    label31.grid(column = 3, row = 5, padx = 10, pady = 10)

    label32 = tk.Label(tab5,text="")
    label32.grid(column = 3, row = 6, padx = 10, pady = 10)

    def grab5():
        label26.config(text=LRL5.get())
        label27.config(text=input_Upper5.get())
        label28.config(text=Amplitude5.get())
        label29.config(text=APW5.get())
        label30.config(text=input_VAmp5.get())
        label31.config(text=VPW5.get())
        label32.config(text=AV_Delay5.get())


    submit5 = tk.Button(tab5, text ="Submit", bg = "black", fg = "red", font=("Rationale", 11), command = lambda:[handle_submit_DOO(tab5Values, tab5Names, 7), grab5()])
    submit5.grid(column = 1, row = 9, padx = 10, pady = 10)

    #TAB 6 - AOOR
    tk.Label(tab6, text ="Lower Rate Limit", fg = "red", bg= "black").grid(column = 0, row = 0, padx = 10, pady = 10)
    tk.Label(tab6, text ="Upper Rate Limit", fg = "red", bg= "black").grid(column = 0, row = 1, padx = 10, pady = 10)
    tk.Label(tab6, text ="Atrial Amplitude", fg = "red", bg= "black").grid(column = 0, row = 2, padx = 10, pady = 10)
    tk.Label(tab6, text ="Atrial Pulse Width", fg = "red", bg= "black").grid(column = 0, row = 3, padx = 10, pady = 10)
    tk.Label(tab6, text ="Maximum Sensor Rate", fg = "red", bg= "black").grid(column = 0, row = 4, padx = 10, pady = 10)
    tk.Label(tab6, text ="Activity Treshold", fg = "red", bg= "black").grid(column = 0, row = 5, padx = 10, pady = 10)
    tk.Label(tab6, text ="Reaction Time", fg = "red", bg= "black").grid(column = 0, row = 6, padx = 10, pady = 10)
    tk.Label(tab6, text ="Response Factor", fg = "red", bg= "black").grid(column = 0, row = 7, padx = 10, pady = 10)
    tk.Label(tab6, text ="Recovery Time", fg = "red", bg= "black").grid(column = 0, row = 8, padx = 10, pady = 10)

    var = tk.StringVar()
    LRL6 = tk.Spinbox(tab6, from_=30, to=175, increment = 1, wrap=True)
    LRL6.grid(column = 1, row = 0, padx = 10, pady = 10)
    input_Upper6 = tk.Spinbox(tab6, from_=50, to=175, increment = 5, wrap=True)
    input_Upper6.grid(column = 1, row = 1, padx = 10, pady = 10)
    Amplitude6 = tk.Spinbox(tab6, from_= 0, to=5000, increment = 100, wrap=True)
    Amplitude6.grid(column = 1, row = 2, padx = 10, pady = 10)
    APW6 = tk.Spinbox(tab6, from_=1, to=30, increment = 1, wrap=True)
    APW6.grid(column = 1, row = 3, padx = 10, pady = 10)
    MSR6 = tk.Spinbox(tab6, from_=50, to=175, increment = 5, wrap=True)
    MSR6.grid(column = 1, row = 4, padx = 10, pady = 10)
    ActivityTreshold6 = tk.Spinbox(tab6,values=("V-Low", "Low", "Med-Low", "Med", "Med-High", "High", "V-High"), wrap=True)
    ActivityTreshold6.grid(column = 1, row = 5, padx = 10, pady = 10)
    REAT6 = tk.Spinbox(tab6, from_=10, to=50, increment = 10, wrap=True)
    REAT6.grid(column = 1, row = 6, padx = 10, pady = 10)
    RF6 = tk.Spinbox(tab6, from_=1, to=16, increment = 1, wrap=True)
    RF6.grid(column = 1, row = 7, padx = 10, pady = 10)
    RCT6 = tk.Spinbox(tab6, from_=2, to=16, increment = 1, wrap=True)
    RCT6.grid(column = 1, row = 8, padx = 10, pady = 10)

    tab6Values.append(int(LRL6.get())) #LRL
    tab6Values.append(0) #Refeac Period
    tab6Values.append(0) #AV Delay
    tab6Values.append(int(APW6.get())) #APW
    tab6Values.append(0) #VPW
    tab6Values.append(int(Amplitude6.get())) #amplitude
    tab6Values.append(0) #Sensing Threshold
    tab6Values.append(ActivityTreshold6) #Activity Treshold
    tab6Values.append(int(RF6.get())) #RF
    tab6Values.append(int(MSR6.get())) #MSR
    tab6Values.append(int(RCT6.get())) #Recover time
    tab6Values.append(int(REAT6.get())) #Reaction time
    tab6Values.append(int(input_Upper6.get()))

    tab6Names.append("LRL6")
    tab6Names.append("input_Upper6")
    tab6Names.append("Amplitude6")
    tab6Names.append("APW6")
    tab6Names.append("MSR6")
    tab6Names.append("ActivityTreshold6")
    tab6Names.append("REAT6")
    tab6Names.append("RF6")
    tab6Names.append("RCT6")


    label33 = tk.Label(tab6,text="")
    label33.grid(column = 3, row = 0, padx = 10, pady = 10)

    label34 = tk.Label(tab6,text="")
    label34.grid(column = 3, row = 1, padx = 10, pady = 10)

    label35 = tk.Label(tab6,text="")
    label35.grid(column = 3, row = 2, padx = 10, pady = 10)

    label36 = tk.Label(tab6,text="")
    label36.grid(column = 3, row = 3, padx = 10, pady = 10)

    label37 = tk.Label(tab6,text="")
    label37.grid(column = 3, row = 4, padx = 10, pady = 10)

    label38 = tk.Label(tab6,text="")
    label38.grid(column = 3, row = 5, padx = 10, pady = 10)

    label39 = tk.Label(tab6,text="")
    label39.grid(column = 3, row = 6, padx = 10, pady = 10)

    label40 = tk.Label(tab6,text="")
    label40.grid(column = 3, row = 7, padx = 10, pady = 10)

    label41 = tk.Label(tab6,text="")
    label41.grid(column = 3, row = 8, padx = 10, pady = 10)

    def grab6():
        label33.config(text=LRL6.get())
        label34.config(text=input_Upper6.get())
        label35.config(text=Amplitude6.get())
        label36.config(text=APW6.get())
        label37.config(text=MSR6.get())
        label38.config(text=ActivityTreshold6.get())
        label39.config(text=REAT6.get())
        label40.config(text=RF6.get())
        label41.config(text=RCT6.get())


    submit6 = tk.Button(tab6, text ="Submit", bg = "black", fg = "red", font=("Rationale", 11), command = lambda:[handle_submit_AOOR(tab6Values, tab6Names, 9), grab6()])
    submit6.grid(column = 1, row = 11, padx = 10, pady = 10)

    #TAB 7  - VOOR
    tk.Label(tab7, text ="Lower Rate Limit", fg = "red", bg= "black").grid(column = 0, row = 0, padx = 10, pady = 10)
    tk.Label(tab7, text ="Upper Rate Limit", fg = "red", bg= "black").grid(column = 0, row = 1, padx = 10, pady = 10)
    tk.Label(tab7, text ="Ventricular Amplitude", fg = "red", bg= "black").grid(column = 0, row = 2, padx = 10, pady = 10)
    tk.Label(tab7, text ="Ventricular Pulse Width", fg = "red", bg= "black").grid(column = 0, row = 3, padx = 10, pady = 10)
    tk.Label(tab7, text ="Maximum Sensor Rate", fg = "red", bg= "black").grid(column = 0, row = 4, padx = 10, pady = 10)
    tk.Label(tab7, text ="Activity Treshold", fg = "red", bg= "black").grid(column = 0, row = 5, padx = 10, pady = 10)
    tk.Label(tab7, text ="Reaction Time", fg = "red", bg= "black").grid(column = 0, row = 6, padx = 10, pady = 10)
    tk.Label(tab7, text ="Response Factor", fg = "red", bg= "black").grid(column = 0, row = 7, padx = 10, pady = 10)
    tk.Label(tab7, text ="Recovery Time", fg = "red", bg= "black").grid(column = 0, row = 8, padx = 10, pady = 10)

    LRL7 = tk.Spinbox(tab7, from_=30, to=175, increment = 1, wrap=True)
    LRL7.grid(column = 1, row = 0, padx = 10, pady = 10)
    input_Upper7 = tk.Spinbox(tab7, from_=50, to=175, increment = 5, wrap=True)
    input_Upper7.grid(column = 1, row = 1, padx = 10, pady = 10)
    Amplitude7 = tk.Spinbox(tab7, from_= 0, to=5000, increment = 100, wrap=True)
    Amplitude7.grid(column = 1, row = 2, padx = 10, pady = 10)
    VPW7 = tk.Spinbox(tab7, from_=1, to=30, increment = 1, wrap=True)
    VPW7.grid(column = 1, row = 3, padx = 10, pady = 10)
    MSR7 = tk.Spinbox(tab7, from_=50, to=175, increment = 5, wrap=True)
    MSR7.grid(column = 1, row = 4, padx = 10, pady = 10)
    ActivityTreshold7 = tk.Spinbox(tab7,values=("V-Low", "Low", "Med-Low", "Med", "Med-High", "High", "V-High"), wrap=True)
    ActivityTreshold7.grid(column = 1, row = 5, padx = 10, pady = 10)
    REAT7 = tk.Spinbox(tab7, from_=10, to=50, increment = 10, wrap=True)
    REAT7.grid(column = 1, row = 6, padx = 10, pady = 10)
    RF7 = tk.Spinbox(tab7, from_=1, to=16, increment = 1, wrap=True)
    RF7.grid(column = 1, row = 7, padx = 10, pady = 10)
    RCT7 = tk.Spinbox(tab7, from_=2, to=16, increment = 1, wrap=True)
    RCT7.grid(column = 1, row = 8, padx = 10, pady = 10)

    tab7Values.append(int(LRL7.get())) #LRL
    tab7Values.append(0) #Refeac Period
    tab7Values.append(0) #AV Delay
    tab7Values.append(0) #APW
    tab7Values.append(int(VPW7.get())) #VPW
    tab7Values.append(int(Amplitude7.get())) #amplitude
    tab7Values.append(0) #Sensing Threshold
    tab7Values.append(ActivityTreshold7) #Activity Treshold
    tab7Values.append(int(RF7.get())) #RF
    tab7Values.append(int(MSR7.get())) #MSR
    tab7Values.append(int(RCT7.get())) #Recover time
    tab7Values.append(int(REAT7.get())) #Reaction time
    tab7Values.append(int(input_Upper7.get()))

    tab7Names.append("LRL7")
    tab7Names.append("input_Upper7")
    tab7Names.append("Amplitude7")
    tab7Names.append("VPW7")
    tab7Names.append("MSR7")
    tab7Names.append("ActivityTreshold7")
    tab7Names.append("REAT7")
    tab7Names.append("RF7")
    tab7Names.append("RCT7")


    label42 = tk.Label(tab7,text="")
    label42.grid(column = 3, row = 0, padx = 10, pady = 10)

    label43 = tk.Label(tab7,text="")
    label43.grid(column = 3, row = 1, padx = 10, pady = 10)

    label44 = tk.Label(tab7,text="")
    label44.grid(column = 3, row = 2, padx = 10, pady = 10)

    label45 = tk.Label(tab7,text="")
    label45.grid(column = 3, row = 3, padx = 10, pady = 10)

    label46 = tk.Label(tab7,text="")
    label46.grid(column = 3, row = 4, padx = 10, pady = 10)

    label47 = tk.Label(tab7,text="")
    label47.grid(column = 3, row = 5, padx = 10, pady = 10)

    label48 = tk.Label(tab7,text="")
    label48.grid(column = 3, row = 6, padx = 10, pady = 10)

    label49 = tk.Label(tab7,text="")
    label49.grid(column = 3, row = 7, padx = 10, pady = 10)

    label50 = tk.Label(tab7,text="")
    label50.grid(column = 3, row = 8, padx = 10, pady = 10)

    def grab7():
        label42.config(text=LRL7.get())
        label43.config(text=input_Upper7.get())
        label44.config(text=Amplitude7.get())
        label45.config(text=VPW7.get())
        label46.config(text=MSR7.get())
        label47.config(text=ActivityTreshold7.get())
        label48.config(text=REAT7.get())
        label49.config(text=RF7.get())
        label50.config(text=RCT7.get())


    submit7 = tk.Button(tab7, text ="Submit", bg = "black", fg = "red", font=("Rationale", 11), command = lambda:[handle_submit_VOOR(tab7Values, tab7Names, 9), grab7()])
    submit7.grid(column = 1, row = 11, padx = 10, pady = 10)

    #TAB 8 - AAIR
    tk.Label(tab8, text ="Lower Rate Limit", fg = "red", bg= "black").grid(column = 0, row = 0, padx = 10, pady = 10)
    tk.Label(tab8, text ="Upper Rate Limit", fg = "red", bg= "black").grid(column = 0, row = 1, padx = 10, pady = 10)
    tk.Label(tab8, text ="Atrial Amplitude", fg = "red", bg= "black").grid(column = 0, row = 2, padx = 10, pady = 10)
    tk.Label(tab8, text ="Atrial Pulse Width", fg = "red", bg= "black").grid(column = 0, row = 3, padx = 10, pady = 10)
    tk.Label(tab8, text ="Maximum Sensory Rate", fg = "red", bg= "black").grid(column = 0, row = 4, padx = 10, pady = 10)
    tk.Label(tab8, text ="Atrial Sensitivity", fg = "red", bg= "black").grid(column = 0, row = 5, padx = 10, pady = 10)
    tk.Label(tab8, text ="ARP", fg = "red", bg= "black").grid(column = 0, row = 6, padx = 10, pady = 10)
    tk.Label(tab8, text ="PVARP", fg = "red", bg= "black").grid(column = 0, row = 7, padx = 10, pady = 10)
    tk.Label(tab8, text ="Hysteresis", fg = "red", bg= "black").grid(column = 0, row = 8, padx = 10, pady = 10)
    tk.Label(tab8, text ="Rate Smoothing", fg = "red", bg= "black").grid(column = 0, row = 9, padx = 10, pady = 10)
    tk.Label(tab8, text ="Activity Treshold", fg = "red", bg= "black").grid(column = 0, row = 10, padx = 10, pady = 10)
    tk.Label(tab8, text ="Reaction Time", fg = "red", bg= "black").grid(column = 0, row = 11, padx = 10, pady = 10)
    tk.Label(tab8, text ="Response Factor", fg = "red", bg= "black").grid(column = 0, row = 12, padx = 10, pady = 10)
    tk.Label(tab8, text ="Recovery Time", fg = "red", bg= "black").grid(column = 0, row = 13, padx = 10, pady = 10)
    LRL8 = tk.Spinbox(tab8, from_=30, to=175, increment = 1, wrap=True)
    LRL8.grid(column = 1, row = 0, padx = 10, pady = 10)
    input_Upper8 = tk.Spinbox(tab8, from_=50, to=175, increment = 5, wrap=True)
    input_Upper8.grid(column = 1, row = 1, padx = 10, pady = 10)
    Amplitude8= tk.Spinbox(tab8, from_= 0, to=5000, increment = 100, wrap=True)
    Amplitude8.grid(column = 1, row = 2, padx = 10, pady = 10)
    APW8 = tk.Spinbox(tab8, from_=1, to=30, increment = 1, wrap=True)
    APW8.grid(column = 1, row = 3, padx = 10, pady = 10)
    MSR8 = tk.Spinbox(tab8, from_=50, to=175, increment = 5, wrap=True)
    MSR8.grid(column = 1, row = 4, padx = 10, pady = 10)
    Sensing_Threshold8 = tk.Spinbox(tab8, from_=0, to=5000, increment = 100, wrap=True)
    Sensing_Threshold8.grid(column = 1, row = 5, padx = 10, pady = 10)
    Refrac_Period8 = tk.Spinbox(tab8, from_=150, to=500, increment = 10, wrap=True)
    Refrac_Period8.grid(column = 1, row = 6, padx = 10, pady = 10)
    PVARP8 = tk.Spinbox(tab8, from_=150, to=500, increment = 10, wrap=True)
    PVARP8.grid(column = 1, row = 7, padx = 10, pady = 10)
    Hysteresis8 = tk.Spinbox(tab8, from_=30, to=175, increment = 1, wrap=True)
    Hysteresis8.grid(column = 1, row = 8, padx = 10, pady = 10)
    Rate_Soothing8 = tk.Spinbox(tab8, from_=0, to=21, increment = 3, wrap=True)
    Rate_Soothing8.grid(column = 1, row = 9, padx = 10, pady = 10)
    ActivityTreshold8 = tk.Spinbox(tab8, values=("V-Low", "Low", "Med-Low", "Med", "Med-High", "High", "V-High"), wrap=True)
    ActivityTreshold8.grid(column = 1, row = 10, padx = 10, pady = 10)
    REAT8 = tk.Spinbox(tab8, from_=10, to=50, increment = 10, wrap=True)
    REAT8.grid(column = 1, row = 11, padx = 10, pady = 10)
    RF8 = tk.Spinbox(tab8, from_=1, to=16, increment = 1, wrap=True)
    RF8.grid(column = 1, row = 12, padx = 10, pady = 10)
    RCT8 = tk.Spinbox(tab8, from_=2, to=16, increment = 1, wrap=True)
    RCT8.grid(column = 1, row = 13, padx = 10, pady = 10)

    tab8Values.append(int(LRL8.get())) #LRL
    tab8Values.append(int(Refrac_Period8.get())) #Refeac Period
    tab8Values.append(0) #AV Delay
    tab8Values.append(int(APW8.get())) #APW
    tab8Values.append(0) #VPW
    tab8Values.append(int(Amplitude8.get())) #amplitude
    tab8Values.append(int(Sensing_Threshold8.get())) #Sensing Threshold
    tab8Values.append(ActivityTreshold8) #Activity Treshold
    tab8Values.append(int(RF8.get())) #RF
    tab8Values.append(int(MSR8.get())) #MSR
    tab8Values.append(int(RCT8.get()))#Recover time
    tab8Values.append(int(REAT8.get())) #Reaction time
    tab8Values.append(int(input_Upper8.get()))
    tab8Values.append(int(PVARP8.get()))
    tab8Values.append(int(Hysteresis8.get()))
    tab8Values.append(int(Rate_Soothing8.get()))

    tab8Names.append("LRL8")
    tab8Names.append("input_Upper8")
    tab8Names.append("Amplitude8")
    tab8Names.append("APW8")
    tab8Names.append("MSR8")
    tab8Names.append("Sensing_Threshold8")
    tab8Names.append("Refrac_Period8")
    tab8Names.append("PVARP8")
    tab8Names.append("Hysteresis8")
    tab8Names.append("Rate_Soothing8")
    tab8Names.append("ActivityTreshold8")
    tab8Names.append("REAT8")
    tab8Names.append("RF8")
    tab8Names.append("RCT8")


    label51 = tk.Label(tab8,text="")
    label51.grid(column = 3, row = 0, padx = 10, pady = 10)

    label52 = tk.Label(tab8,text="")
    label52.grid(column = 3, row = 1, padx = 10, pady = 10)

    label53 = tk.Label(tab8,text="")
    label53.grid(column = 3, row = 2, padx = 10, pady = 10)

    label54 = tk.Label(tab8,text="")
    label54.grid(column = 3, row = 3, padx = 10, pady = 10)

    label55 = tk.Label(tab8,text="")
    label55.grid(column = 3, row = 4, padx = 10, pady = 10)

    label56 = tk.Label(tab8,text="")
    label56.grid(column = 3, row = 5, padx = 10, pady = 10)

    label57 = tk.Label(tab8,text="")
    label57.grid(column = 3, row = 6, padx = 10, pady = 10)

    label58 = tk.Label(tab8,text="")
    label58.grid(column = 3, row = 7, padx = 10, pady = 10)

    label59 = tk.Label(tab8,text="")
    label59.grid(column = 3, row = 8, padx = 10, pady = 10)

    label60 = tk.Label(tab8,text="")
    label60.grid(column = 3, row = 9, padx = 10, pady = 10)

    label61 = tk.Label(tab8,text="")
    label61.grid(column = 3, row = 10, padx = 10, pady = 10)

    label62 = tk.Label(tab8,text="")
    label62.grid(column = 3, row = 11, padx = 10, pady = 10)

    label63 = tk.Label(tab8,text="")
    label63.grid(column = 3, row = 12, padx = 10, pady = 10)

    label64 = tk.Label(tab8,text="")
    label64.grid(column = 3, row = 13, padx = 10, pady = 10)


    def grab8():
        label51.config(text=LRL8.get())
        label52.config(text=input_Upper8.get())
        label53.config(text=Amplitude8.get())
        label54.config(text=APW8.get())
        label55.config(text=MSR8.get())
        label56.config(text=Sensing_Threshold8.get())
        label57.config(text=Refrac_Period8.get())
        label58.config(text=PVARP8.get())
        label59.config(text=Hysteresis8.get())
        label60.config(text=Rate_Soothing8.get())
        label61.config(text=ActivityTreshold8.get())
        label62.config(text=REAT8.get())
        label63.config(text=RF8.get())
        label64.config(text=RCT8.get())


    submit8 = tk.Button(tab8, text ="Submit", bg = "black", fg = "red", font=("Rationale", 11), command = lambda:[handle_submit_AAIR(tab8Values, tab8Names, 14), grab8()])
    submit8.grid(column = 1, row = 16, padx = 10, pady = 10)

    #TAB 9 - VVIR
    tk.Label(tab9, text ="Lower Rate Limit", fg = "red", bg= "black").grid(column = 0, row = 0, padx = 10, pady = 10)
    tk.Label(tab9, text ="Upper Rate Limit", fg = "red", bg= "black").grid(column = 0, row = 1, padx = 10, pady = 10)
    tk.Label(tab9, text ="Ventricular Amplitude", fg = "red", bg= "black").grid(column = 0, row = 2, padx = 10, pady = 10)
    tk.Label(tab9, text ="Ventricular Pulse Width", fg = "red", bg= "black").grid(column = 0, row = 3, padx = 10, pady = 10)
    tk.Label(tab9, text ="Maximum Sensory Rate", fg = "red", bg= "black").grid(column = 0, row = 4, padx = 10, pady = 10)
    tk.Label(tab9, text ="Ventricular Sensitivity", fg = "red", bg= "black").grid(column = 0, row = 5, padx = 10, pady = 10)
    tk.Label(tab9, text ="VRP", fg = "red", bg= "black").grid(column = 0, row = 6, padx = 10, pady = 10)
    tk.Label(tab9, text ="Hysteresis", fg = "red", bg= "black").grid(column = 0, row = 7, padx = 10, pady = 10)
    tk.Label(tab9, text ="Rate Smoothing", fg = "red", bg= "black").grid(column = 0, row = 8, padx = 10, pady = 10)
    tk.Label(tab9, text ="Activity Treshold", fg = "red", bg= "black").grid(column = 0, row = 9, padx = 10, pady = 10)
    tk.Label(tab9, text ="Reaction Time", fg = "red", bg= "black").grid(column = 0, row = 10, padx = 10, pady = 10)
    tk.Label(tab9, text ="Response Factor", fg = "red", bg= "black").grid(column = 0, row = 11, padx = 10, pady = 10)
    tk.Label(tab9, text ="Recovery Time", fg = "red", bg= "black").grid(column = 0, row = 12, padx = 10, pady = 10)
    LRL9 = tk.Spinbox(tab9, from_=30, to=175, increment = 1, wrap=True)
    LRL9.grid(column = 1, row = 0, padx = 10, pady = 10)
    input_Upper9 = tk.Spinbox(tab9, from_=50, to=175, increment = 5, wrap=True)
    input_Upper9.grid(column = 1, row = 1, padx = 10, pady = 10)
    Amplitude9 = tk.Spinbox(tab9, from_= 0, to=5000, increment = 100, wrap=True)
    Amplitude9.grid(column = 1, row = 2, padx = 10, pady = 10)
    VPW9 = tk.Spinbox(tab9, from_=1, to=30, increment = 1, wrap=True)
    VPW9.grid(column = 1, row = 3, padx = 10, pady = 10)
    MSR9 = tk.Spinbox(tab9, from_=50, to=175, increment = 5, wrap=True)
    MSR9.grid(column = 1, row = 4, padx = 10, pady = 10)
    Sensing_Threshold9 = tk.Spinbox(tab9, from_=0, to=5000, increment = 100, wrap=True)
    Sensing_Threshold9.grid(column = 1, row = 5, padx = 10, pady = 10)
    Refrac_Period9 = tk.Spinbox(tab9, from_=150, to=500, increment = 10, wrap=True)
    Refrac_Period9.grid(column = 1, row = 6, padx = 10, pady = 10)
    Hysteresis9 = tk.Spinbox(tab9, from_=30, to=175, increment = 1, wrap=True)
    Hysteresis9.grid(column = 1, row = 7, padx = 10, pady = 10)
    Rate_Soothing9 = tk.Spinbox(tab9, from_=0, to=21, increment = 3, wrap=True)
    Rate_Soothing9.grid(column = 1, row = 8, padx = 10, pady = 10)
    ActivityTreshold9 = tk.Spinbox(tab9, values=("V-Low", "Low", "Med-Low", "Med", "Med-High", "High", "V-High"), wrap=True)
    ActivityTreshold9.grid(column = 1, row = 9, padx = 10, pady = 10)
    REAT9 = tk.Spinbox(tab9, from_=10, to=50, increment = 10, wrap=True)
    REAT9.grid(column = 1, row = 10, padx = 10, pady = 10)
    RF9 = tk.Spinbox(tab9, from_=1, to=16, increment = 1, wrap=True)
    RF9.grid(column = 1, row = 11, padx = 10, pady = 10)
    RCT9 = tk.Spinbox(tab9, from_=2, to=16, increment = 1, wrap=True)
    RCT9.grid(column = 1, row = 12, padx = 10, pady = 10)

    tab9Values.append(int(LRL9.get())) #LRL
    tab9Values.append(int(Refrac_Period9.get())) #Refeac Period
    tab9Values.append(0) #AV Delay
    tab9Values.append(0) #APW
    tab9Values.append(int(VPW9.get())) #VPW
    tab9Values.append(int(Amplitude9.get())) #amplitude
    tab9Values.append(int(Sensing_Threshold9.get())) #Sensing Threshold
    tab9Values.append(ActivityTreshold9) #Activity Treshold
    tab9Values.append(int(RF9.get())) #RF
    tab9Values.append(int(MSR9.get())) #MSR
    tab9Values.append(int(RCT9.get())) #Recover time
    tab9Values.append(int(REAT9.get())) #Reaction time
    tab9Values.append(int(input_Upper9.get()))
    tab8Values.append(int(Hysteresis9.get()))
    tab8Values.append(int(Rate_Soothing9.get()))

    tab9Names.append("LRL9")
    tab9Names.append("input_Upper9")
    tab9Names.append("Amplitude9")
    tab9Names.append("VPW9")
    tab9Names.append("MSR9")
    tab9Names.append("Sensing_Threshold9")
    tab9Names.append("Refrac_Period9")
    tab9Names.append("Hysteresis9")
    tab9Names.append("Rate_Soothing9")
    tab9Names.append("ActivityTreshold9")
    tab9Names.append("REAT9")
    tab9Names.append("RF9")
    tab9Names.append("RCT9")


    label65 = tk.Label(tab9,text="")
    label65.grid(column = 3, row = 0, padx = 10, pady = 10)

    label66 = tk.Label(tab9,text="")
    label66.grid(column = 3, row = 1, padx = 10, pady = 10)

    label67 = tk.Label(tab9,text="")
    label67.grid(column = 3, row = 2, padx = 10, pady = 10)

    label68 = tk.Label(tab9,text="")
    label68.grid(column = 3, row = 3, padx = 10, pady = 10)

    label69 = tk.Label(tab9,text="")
    label69.grid(column = 3, row = 4, padx = 10, pady = 10)

    label70 = tk.Label(tab9,text="")
    label70.grid(column = 3, row = 5, padx = 10, pady = 10)

    label71 = tk.Label(tab9,text="")
    label71.grid(column = 3, row = 6, padx = 10, pady = 10)

    label72 = tk.Label(tab9,text="")
    label72.grid(column = 3, row = 7, padx = 10, pady = 10)

    label73 = tk.Label(tab9,text="")
    label73.grid(column = 3, row = 8, padx = 10, pady = 10)

    label74 = tk.Label(tab9,text="")
    label74.grid(column = 3, row = 9, padx = 10, pady = 10)

    label75 = tk.Label(tab9,text="")
    label75.grid(column = 3, row = 10, padx = 10, pady = 10)

    label76 = tk.Label(tab9,text="")
    label76.grid(column = 3, row = 11, padx = 10, pady = 10)

    label77 = tk.Label(tab9,text="")
    label77.grid(column = 3, row = 12, padx = 10, pady = 10)

    def grab9():
        label65.config(text=LRL9.get())
        label66.config(text=input_Upper9.get())
        label67.config(text=Amplitude9.get())
        label68.config(text=VPW9.get())
        label69.config(text=MSR9.get())
        label70.config(text=Sensing_Threshold9.get())
        label71.config(text=Refrac_Period9.get())
        label72.config(text=Hysteresis9.get())
        label73.config(text=Rate_Soothing9.get())
        label74.config(text=ActivityTreshold9.get())
        label75.config(text=REAT9.get())
        label76.config(text=RF9.get())
        label77.config(text=RCT9.get())


    submit9 = tk.Button(tab9, text ="Submit", bg = "black", fg = "red", font=("Rationale", 11), command = lambda:[handle_submit_VVIR(tab9Values, tab9Names, 13), grab9()])
    submit9.grid(column = 1, row = 15, padx = 10, pady = 10)

    #TAB 10 - DOOR
    tk.Label(tab10, text ="Lower Rate Limit", fg = "red", bg= "black").grid(column = 0, row = 0, padx = 10, pady = 10)
    tk.Label(tab10, text ="Upper Rate Limit", fg = "red", bg= "black").grid(column = 0, row = 1, padx = 10, pady = 10)
    tk.Label(tab10, text ="Maximum Sensory Rate", fg = "red", bg= "black").grid(column = 0, row = 2, padx = 10, pady = 10)
    tk.Label(tab10, text ="Fixed AV Delay", fg = "red", bg= "black").grid(column = 0, row = 3, padx = 10, pady = 10)
    tk.Label(tab10, text ="Ventricular Amplitude", fg = "red", bg= "black").grid(column = 0, row = 4, padx = 10, pady = 10)
    tk.Label(tab10, text ="Ventricular Pulse Width", fg = "red", bg= "black").grid(column = 0, row = 5, padx = 10, pady = 10)
    tk.Label(tab10, text ="Atrial Amplitude", fg = "red", bg= "black").grid(column = 0, row = 6, padx = 10, pady = 10)
    tk.Label(tab10, text ="Atrial Pulse Width", fg = "red", bg= "black").grid(column = 0, row = 7, padx = 10, pady = 10)
    tk.Label(tab10, text ="Activity Treshold", fg = "red", bg= "black").grid(column = 0, row = 8, padx = 10, pady = 10)
    tk.Label(tab10, text ="Reaction Time", fg = "red", bg= "black").grid(column = 0, row = 9, padx = 10, pady = 10)
    tk.Label(tab10, text ="Response Factor", fg = "red", bg= "black").grid(column = 0, row = 10, padx = 10, pady = 10)
    tk.Label(tab10, text ="Recovery Time", fg = "red", bg= "black").grid(column = 0, row = 11, padx = 10, pady = 10)

    LRL10 = tk.Spinbox(tab10, from_=30, to=175, increment = 1, wrap=True)
    LRL10.grid(column = 1, row = 0, padx = 10, pady = 10)
    input_Upper10 = tk.Spinbox(tab10, from_=50, to=175, increment = 5, wrap=True)
    input_Upper10.grid(column = 1, row = 1, padx = 10, pady = 10)
    MSR10 = tk.Spinbox(tab10, from_=50, to=175, increment = 5, wrap=True)
    MSR10.grid(column = 1, row = 2, padx = 10, pady = 10)
    AV_Delay10 = tk.Spinbox(tab10, from_=70, to=300, increment = 10, wrap=True)
    AV_Delay10.grid(column = 1, row = 3, padx = 10, pady = 10)
    input_VAmp10 = tk.Spinbox(tab10, from_=0, to=5, increment = 0.1, wrap=True)
    input_VAmp10.grid(column = 1, row = 4, padx = 10, pady = 10)

    VPW10 = tk.Spinbox(tab10, from_=1, to=30, increment = 1, wrap=True)
    VPW10.grid(column = 1, row = 5, padx = 10, pady = 10)
    Amplitude10 = tk.Spinbox(tab10, from_= 0, to=5000, increment = 100, wrap=True)
    Amplitude10.grid(column = 1, row = 6, padx = 10, pady = 10)
    APW10 = tk.Spinbox(tab10, from_=1, to=30, increment = 1, wrap=True)
    APW10.grid(column = 1, row = 7, padx = 10, pady = 10)
    ActivityTreshold10 = tk.Spinbox(tab10, values=("V-Low", "Low", "Med-Low", "Med", "Med-High", "High", "V-High"), wrap=True)
    ActivityTreshold10.grid(column = 1, row = 8, padx = 10, pady = 10)
    REAT10 = tk.Spinbox(tab10, from_=10, to=50, increment = 10, wrap=True)
    REAT10.grid(column = 1, row = 9, padx = 10, pady = 10)
    RF10 = tk.Spinbox(tab10, from_=1, to=16, increment = 1, wrap=True)
    RF10.grid(column = 1, row = 10, padx = 10, pady = 10)
    RCT10 = tk.Spinbox(tab10, from_=2, to=16, increment = 1, wrap=True)
    RCT10.grid(column = 1, row = 11, padx = 10, pady = 10)

    tab10Values.append(int(LRL10.get())) #LRL
    tab10Values.append(0) #Refeac Period
    tab10Values.append(int(AV_Delay10.get())) #AV Delay
    tab10Values.append(int(APW10.get())) #APW
    tab10Values.append(int(VPW10.get())) #VPW
    tab10Values.append(int(Amplitude10.get())) #amplitude
    tab10Values.append(0) #Sensing Threshold
    tab10Values.append(ActivityTreshold10) #Activity Treshold
    tab10Values.append(int(RF10.get())) #RF
    tab10Values.append(int(MSR10.get())) #MSR
    tab10Values.append(int(RCT10.get())) #Recover time
    tab10Values.append(int(REAT10.get())) #Reaction time
    tab10Values.append(int(input_Upper10.get()))

    tab10Names.append("LRL10")
    tab10Names.append("input_Upper10")
    tab10Names.append("input_VAmp10")
    tab10Names.append("VPW10")
    tab10Names.append("Amplitude10")
    tab10Names.append("APW10")
    tab10Names.append("MSR10")
    tab10Names.append("AV_Delay10")
    tab10Names.append("ActivityTreshold10")
    tab10Names.append("REAT10")
    tab10Names.append("RF10")
    tab10Names.append("RCT10")


    label78 = tk.Label(tab10,text="")
    label78.grid(column = 3, row = 0, padx = 10, pady = 10)

    label79 = tk.Label(tab10,text="")
    label79.grid(column = 3, row = 1, padx = 10, pady = 10)

    label80 = tk.Label(tab10,text="")
    label80.grid(column = 3, row = 2, padx = 10, pady = 10)

    label81 = tk.Label(tab10,text="")
    label81.grid(column = 3, row = 3, padx = 10, pady = 10)

    label82 = tk.Label(tab10,text="")
    label82.grid(column = 3, row = 4, padx = 10, pady = 10)

    label83 = tk.Label(tab10,text="")
    label83.grid(column = 3, row = 5, padx = 10, pady = 10)

    label84 = tk.Label(tab10,text="")
    label84.grid(column = 3, row = 6, padx = 10, pady = 10)

    label85 = tk.Label(tab10,text="")
    label85.grid(column = 3, row = 7, padx = 10, pady = 10)

    label86 = tk.Label(tab10,text="")
    label86.grid(column = 3, row = 8, padx = 10, pady = 10)

    label87 = tk.Label(tab10,text="")
    label87.grid(column = 3, row = 9, padx = 10, pady = 10)

    label88 = tk.Label(tab10,text="")
    label88.grid(column = 3, row = 10, padx = 10, pady = 10)

    label89 = tk.Label(tab10,text="")
    label89.grid(column = 3, row = 11, padx = 10, pady = 10)

    def grab10():
        label78.config(text=LRL10.get())
        label79.config(text=input_Upper10.get())
        label80.config(text=Amplitude10.get())
        label81.config(text=APW10.get())
        label82.config(text=input_VAmp10.get())
        label83.config(text=VPW10.get())
        label84.config(text=MSR10.get())
        label85.config(text=AV_Delay10.get())
        label86.config(text=ActivityTreshold10.get())
        label87.config(text=REAT10.get())
        label88.config(text=RF10.get())
        label89.config(text=RCT10.get())


    submit10 = tk.Button(tab10, text ="Submit", bg = "black", fg = "red", font=("Rationale", 11), command = lambda:[handle_submit_DOOR(tab10Values, tab10Names, 12), grab10()])
    submit10.grid(column = 1, row = 14, padx = 10, pady = 10)

    window.mainloop()

def handle_submit_AOO(values, names, num): 
    usersinfo = open("AOO.txt", "w")   
    for i in range(num):
        if(values[i]!=0):
            usersinfo.write(str(values[i])+ "\n")
    serCom.getParams(1, 0, values)
    usersinfo.close()

def handle_submit_VOO(values, names, num):
    usersinfo = open("VOO.txt", "w")   
    for i in range(num):
        if(values[i]!=0):
            usersinfo.write(str(values[i])+ "\n")
    serCom.getParams(2, 0, values)
    usersinfo.close()

def handle_submit_AAI(values, names, num):
    usersinfo = open("AAI.txt", "w")   
    for i in range(num):
        if(values[i]!=0):
            usersinfo.write(str(values[i])+ "\n")
    serCom.getParams(3, 0, values)
    usersinfo.close()

def handle_submit_VVI(values, names, num):
    usersinfo = open("VVI.txt", "w")   
    for i in range(num):
        if(values[i]!=0):
            usersinfo.write(str(values[i])+ "\n")
    serCom.getParams(4, 0, values)
    usersinfo.close()

def handle_submit_DOO(values, names, num):
    usersinfo = open("DOO.txt", "w")   
    for i in range(num):
        if(values[i]!=0):
            usersinfo.write(str(values[i])+ "\n")
    serCom.getParams(5, 0, values)
    usersinfo.close()

def handle_submit_AOOR(values, names, num):
    usersinfo = open("AOOR.txt", "w")   
    for i in range(num):
        if(values[i]!=0):
            usersinfo.write(str(values[i])+ "\n")
    serCom.getParams(1, 1, values)
    usersinfo.close()

def handle_submit_VOOR(values, names, num):
    usersinfo = open("VOOR.txt", "w")   
    for i in range(num):
        if(values[i]!=0):
            usersinfo.write(str(values[i])+ "\n")
    serCom.getParams(2, 1, values)
    usersinfo.close()

def handle_submit_AAIR(values, names, num):
    usersinfo = open("AAIR.txt", "w")   
    for i in range(num):
        if(values[i]!=0):
            usersinfo.write(str(values[i])+ "\n")
    serCom.getParams(3, 1, values)
    usersinfo.close()

def handle_submit_VVIR(values, names, num):
    usersinfo = open("VVIR.txt", "w")   
    for i in range(num):
        if(values[i]!=0):
            usersinfo.write(str(values[i])+ "\n")
    serCom.getParams(4, 1, values)
    usersinfo.close()

def handle_submit_DOOR(values, names, num):
    usersinfo = open("DOOR.txt", "w")   
    for i in range(num):
        if(values[i]!=0):
            usersinfo.write(str(values[i])+ "\n")
    serCom.getParams(5, 1, values)
    usersinfo.close()
