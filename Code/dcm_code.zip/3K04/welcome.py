import tkinter as tk
from tkinter import Frame, font
from tkinter import ttk
from tkinter.constants import N
from tkinter.font import Font 
import login as loginScreen

def main():
    #creating the welcome window 
    window = tk.Tk()
    window.geometry("500x150")
    window.configure(bg="black")
    window.title("Pacemaker DCM")

    #addig widgets
    frame_entry = tk.Frame(master=window, bg= "black", width="700", height="350")
    message = tk.Label(master=frame_entry, text = "Welcome to the Pacemaker DCM", fg = "red", bg="black", 
        font=("Aldhabi", 20))
    login_button = tk.Button (master=frame_entry, text="Login", bg = "black", 
        fg = "red",
        font= ("Rationale", 12),
        command= lambda:loginScreen.handle_welcome_login()
    )

    #organizing the widgets
    frame_entry.grid(row=0, column =0, padx =20)
    message.grid(row = 0, column=1, sticky="N"+"S"+"E"+"W")
    login_button.grid(row = 1, column=1, sticky= "S")

    window.mainloop()

    
if __name__ == "__main__":
    main()