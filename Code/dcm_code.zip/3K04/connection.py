import tkinter as tk
from tkinter import Frame, font
from tkinter import ttk
from tkinter.constants import N
from tkinter.font import Font 

def handle_connections():
    windowComms = tk.Tk()
    windowComms.geometry("500x200")
    windowComms.configure(bg="black")
    windowComms.title("communication")
    frame_entryComms = tk.Frame(master=windowComms, bg ="black")

    label2 = tk.Label(master=frame_entryComms, text = "              Enter Pacemaker                 ", fg = "red", bg="black", 
        font=("Aldhabi", 12))
    input_pacemaker = tk.Entry(master=frame_entryComms, fg = "black", width = 20, font=("Rationale", 12, "bold"))

    check = tk.Button(master=frame_entryComms, text ="Check", bg = "black", fg = "red", font=("Rationale", 12), command = lambda:handle_check(input_pacemaker, frame_entryComms))
    
    frame_entryComms.grid(row=0, column=0)
    label2.grid(row=1, column=0)
    input_pacemaker.grid(row=1, column = 1)
    check.grid(column = 1, row = 2, padx = 10, pady = 10)

    windowComms.mainloop()

           
def previous(pacemakername):
    name = pacemakername.get()
    file = open("pacemakernames.txt", "r")
    if (name in file.read()):
        msg = "Previously connected"
    else:
        msg = "New DCM connection"
        file.close()
        file1 = open("pacemakernames.txt", "a")
        file1.write(name+"\n")
        file1.close()
    return msg
    file.close()

def communication():
    file = open("communicate.txt","r")
    if (file.read() == "true"):
        msg = "DCM is communicating"
    else:
        msg = "DCM is !communicating"
    return msg
    file.close()


def handle_check(input_pacemaker, frame_entryComms):
    msgComms = communication()
    msgPrev = previous(input_pacemaker)
    coms = tk.Label(master=frame_entryComms, text = msgComms, fg = "red", bg="black", 
        font=("Aldhabi", 12))
    prev = tk.Label(master=frame_entryComms, text = msgPrev, fg = "red", bg="black", 
        font=("Aldhabi", 12))
    coms.grid(row=3, column=0)
    prev.grid(row=4, column=0)